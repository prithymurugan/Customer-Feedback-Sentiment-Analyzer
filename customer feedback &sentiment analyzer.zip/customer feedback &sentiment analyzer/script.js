function analyzeFeedback() {

    const text = document.getElementById("feedback")
        .value
        .toLowerCase();

    const positiveWords = [
        "good", "great", "excellent", "amazing",
        "happy", "love", "satisfied", "best"
    ];

    const negativeWords = [
        "bad", "poor", "worst", "hate",
        "terrible", "angry", "slow", "disappointed"
    ];

    let positive = 0;
    let negative = 0;

    positiveWords.forEach(word => {
        if (text.includes(word)) positive++;
    });

    negativeWords.forEach(word => {
        if (text.includes(word)) negative++;
    });

    let sentiment;
    let score;

    if (positive > negative) {
        sentiment = "Positive 😊";
        score = positive * 20;
    }
    else if (negative > positive) {
        sentiment = "Negative 😞";
        score = negative * -20;
    }
    else {
        sentiment = "Neutral 😐";
        score = 0;
    }

    document.getElementById("sentiment").innerText =
        "Sentiment: " + sentiment;

    document.getElementById("score").innerText =
        "Score: " + score;

    document.getElementById("message").innerText =
        "Customer feedback analyzed successfully.";
}